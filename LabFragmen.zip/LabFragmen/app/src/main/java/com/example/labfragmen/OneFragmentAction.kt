package com.example.labfragmen

interface OneFragmentAction {
    fun onClickFragmentButton()
}